import "./Testimonial.scss";

const Testimonial = () =>{

    return(
        <div>
            About
        </div>
    );
}
export default Testimonial;